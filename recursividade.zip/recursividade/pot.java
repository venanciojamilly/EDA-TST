public class pot {
    public static double pote(double n, int a){
        
        if ( a== 0){
            return n;
        }
         return n*pote(n,a-1);
    }

    public static void main (String args[]){
        System.out.println(pote(2.0,3));
    }
}
