public class buscabinaria {

    public int buscab(int[] v, int n, int ini, int fim) {
        if (ini < fim) {
            int meio = (ini + fim) / 2;

            if (v[meio] == n)
                return meio;

            if (n < v[meio])
                return buscab(v, n, ini, meio - 1);
            else
                return buscab(v, n, meio + 1, fim);
        } else {
            return -1;
        }
    }
}