public class busca {

    public static boolean buscar(int[] array, int n, int i){
        if ( i == array.length){
            return false;
        }
        if ( array[i] == n ){
            return true;
        }
         return buscar(array,n,i + 1);
    }
    public static void main(String args[]){
        int[] a = new int[3];
        a[0] = 0;
        a[1] = 1;
        a[2] = 2;
        System.out.println(buscar(a,5,0));
    }
}
