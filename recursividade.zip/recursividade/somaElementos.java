public class somaElementos{


    public static int somaDoisElementos(int x, int y){
         if (y == 0){
            return x; 
         }
            return x +somaDoisElementos(x,y - 1); 
    }

    public static void main (String args[]){
        System.out.println(somaDoisElementos(1, 0));
    }
}