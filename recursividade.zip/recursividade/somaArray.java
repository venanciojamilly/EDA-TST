
public class somaArray {
    public static double somaArrays(double[] array, int i){
        if ( i == array.length - 1){
            return 0;  
        } 
        return array[i + 1] + somaArrays(array, i + 1);
}
 public static void main (String[] args){
    double[] a = new double[3];
        a[0] = 0;
        a[1] = 1;
        a[2] = 2;
    System.out.println(somaArrays(a,0));
 }
}
